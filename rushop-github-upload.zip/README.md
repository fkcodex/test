# RuShop

RuShop is a static boutique bag ecommerce demo built with HTML, CSS, and JavaScript.

Expected GitHub Pages URL:

https://fkcodex.github.io/test/
