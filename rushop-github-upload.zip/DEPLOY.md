# RuShop GitHub Pages Deploy

Repository:

https://github.com/fkcodex/test

Final website URL after deploy:

https://fkcodex.github.io/test/

## Important

Upload the contents of this folder to the repository root.

Correct:

- `index.html`
- `styles.css`
- `app.js`
- `assets/...`
- `.github/workflows/pages.yml`

Wrong:

- `rushop-github-upload/index.html`

Do not upload the folder itself as one nested folder.

## Upload Steps

1. Open https://github.com/fkcodex/test
2. If the repository is empty, click `uploading an existing file`.
3. If the repository is not empty, click `Add file` > `Upload files`.
4. Open this local folder on your computer:
   `C:\Users\kench\OneDrive\文件\skills\codex_product\rushop-github-upload`
5. Select all files and folders inside it:
   - `.github`
   - `assets`
   - `index.html`
   - `styles.css`
   - `app.js`
   - `README.md`
   - `DEPLOY.md`
6. Drag those selected items into GitHub's upload page.
7. Wait until all files finish uploading.
8. In the commit message box, type:
   `Deploy RuShop site`
9. Click `Commit changes`.

## Enable Pages

1. In the repository, open `Settings`.
2. In the left menu, click `Pages`.
3. Under `Build and deployment`, set `Source` to `GitHub Actions`.
4. Go back to the repository main page.
5. Click the `Actions` tab.
6. Wait for `Deploy RuShop to GitHub Pages` to show a green check mark.

## Open Website

After the workflow succeeds, open:

https://fkcodex.github.io/test/

If it shows a 404 at first, wait 1-3 minutes and refresh.
