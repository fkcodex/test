const products = [
  ["Aurelia Tote", "Totes", 428, "Saffiano leather", "Oxblood", "Fits 14-inch laptop", "#7b1532", "#d8a953", "tote", "stripe"],
  ["Marais Satchel", "Shoulder Bags", 386, "Smooth calf leather", "Forest", "Top handle and strap", "#0f5c48", "#c7a36a", "satchel", "window"],
  ["Valence Crossbody", "Crossbody", 248, "Pebbled leather", "Cobalt", "Adjustable strap", "#165a9f", "#d9d5cc", "camera", "dot"],
  ["Nocturne Clutch", "Clutches", 218, "Satin weave", "Black Pearl", "Evening essentials", "#161616", "#d6b15e", "clutch", "fan"],
  ["Siena Bucket", "Shoulder Bags", 332, "Grain leather", "Cinnamon", "Drawstring closure", "#9a4f22", "#204f43", "bucket", "wave"],
  ["Bergen Backpack", "Backpacks", 398, "Coated canvas", "Graphite", "Tablet sleeve", "#3c4246", "#b28a4a", "backpack", "grid"],
  ["Luna Crescent", "Shoulder Bags", 298, "Nappa leather", "Ivory", "Magnetic flap", "#e8dfcf", "#6b1530", "crescent", "arc"],
  ["Milan Mini", "Crossbody", 236, "Patent leather", "Cherry", "Compact phone fit", "#b51235", "#f1c27d", "mini", "spot"],
  ["Capri Shopper", "Totes", 364, "Woven leather", "Sea Green", "Weekend capacity", "#0d7566", "#eedfbd", "shopper", "basket"],
  ["Opal Frame Bag", "Clutches", 275, "Box calf leather", "Cream Opal", "Kiss-lock frame", "#f0e7d6", "#1f453d", "frame", "gem"],
  ["Kyoto Hobo", "Shoulder Bags", 348, "Soft suede", "Plum", "Slouch silhouette", "#59204f", "#cfae6d", "hobo", "petal"],
  ["Riviera Saddle", "Crossbody", 315, "Vegetable leather", "Tan Saddle", "Curved flap", "#b56b31", "#183f68", "saddle", "stitch"],
  ["Celeste Baguette", "Shoulder Bags", 284, "Metallic leather", "Silver Blue", "Under-arm carry", "#9fb8c6", "#30343b", "baguette", "shine"],
  ["Monaco Vanity", "Crossbody", 345, "Embossed leather", "Bottle Green", "Structured case", "#07483b", "#d7b45f", "vanity", "tile"],
  ["Arden Weekender", "Totes", 468, "Waxed canvas", "Deep Olive", "Overnight scale", "#46513a", "#b57242", "duffle", "band"],
  ["Vesper Envelope", "Clutches", 198, "Matte leather", "Wine", "Slim evening carry", "#7c1d2f", "#ede3d0", "envelope", "chevron"],
  ["Florence Top Handle", "Shoulder Bags", 412, "Croc-embossed leather", "Espresso", "Polished lock", "#4a2c22", "#c9a456", "tophandle", "croc"],
  ["Oslo Sling", "Crossbody", 255, "Nylon and leather", "Stone Grey", "Hands-free carry", "#767c80", "#102a43", "sling", "diagonal"],
  ["Mirage Minaudiere", "Clutches", 306, "Acrylic shell", "Amber Smoke", "Chain strap inside", "#bd7c34", "#3a2518", "box", "marble"],
  ["Verona Day Tote", "Totes", 392, "Grain leather", "Navy Ink", "Zip center pocket", "#1e2e58", "#c7a365", "tote", "panel"],
  ["Paloma Soft Tote", "Totes", 338, "Supple leather", "Blush", "Folded side gusset", "#d48a96", "#54323a", "shopper", "ribbon"],
  ["Lucerne Saddle Mini", "Crossbody", 288, "Smooth leather", "Alpine Blue", "Front tab closure", "#37759d", "#ece0c7", "saddle", "snow"],
  ["Aster Chain Bag", "Shoulder Bags", 326, "Quilted leather", "Lilac", "Chain shoulder strap", "#9a83bd", "#232323", "flap", "quilt"],
  ["Prague Doctor Bag", "Shoulder Bags", 438, "Polished calf leather", "Merlot", "Wide mouth frame", "#6e1830", "#d5a647", "doctor", "line"],
  ["Como Camera Bag", "Crossbody", 246, "Pebbled leather", "Moss", "Double zip", "#586b3b", "#f2d28b", "camera", "leaf"],
  ["Tivoli Belt Bag", "Crossbody", 225, "Coated leather", "Ink Black", "Convertible belt", "#111820", "#b58b55", "belt", "orbit"],
  ["Zurich Laptop Tote", "Totes", 452, "Structured leather", "Charcoal", "Padded laptop zone", "#34383d", "#c55d37", "tote", "tech"],
  ["Daphne Pouch", "Clutches", 184, "Lambskin leather", "Citrine", "Soft wristlet", "#d8a72c", "#493b10", "pouch", "sun"],
  ["Amalfi Raffia Tote", "Totes", 318, "Raffia and leather", "Natural Black", "Beach-to-city scale", "#c8a66a", "#151515", "raffia", "weave"],
  ["Geneva Compact Backpack", "Backpacks", 372, "Nappa leather", "Pine", "Hidden back pocket", "#184b3f", "#ddd1bd", "backpack", "pine"]
].map((item, index) => ({
  id: index + 1,
  name: item[0],
  category: item[1],
  price: item[2],
  material: item[3],
  color: item[4],
  capacity: item[5],
  base: item[6],
  accent: item[7],
  shape: item[8],
  pattern: item[9],
  image: `product-${String(index + 1).padStart(2, "0")}.webp`,
  description: `${item[0]} pairs ${item[3].toLowerCase()} with a ${item[4].toLowerCase()} finish for a clean boutique carry profile.`
}));

const state = {
  category: "All",
  query: "",
  sort: "featured",
  cart: []
};

const grid = document.querySelector("#productGrid");
const template = document.querySelector("#productTemplate");
const resultCount = document.querySelector("#resultCount");
const emptyState = document.querySelector("#emptyState");
const searchInput = document.querySelector("#searchInput");
const sortSelect = document.querySelector("#sortSelect");
const categoryButtons = [...document.querySelectorAll(".category-button")];
const cartDrawer = document.querySelector("#cartDrawer");
const openCart = document.querySelector("#openCart");
const closeCart = document.querySelector("#closeCart");
const cartItems = document.querySelector("#cartItems");
const cartCount = document.querySelector("#cartCount");
const cartTotal = document.querySelector("#cartTotal");
const checkoutButton = document.querySelector("#checkoutButton");
const quickView = document.querySelector("#quickView");
const closeQuickView = document.querySelector("#closeQuickView");
const quickAdd = document.querySelector("#quickAdd");
let activeQuickProduct = null;
let previousFocus = null;

function money(value) {
  return `$${value.toLocaleString("en-US")}`;
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}

function productArt(product, size = "card") {
  const loading = size === "card" && product.id > 8 ? "lazy" : "eager";
  return `
    <img
      src="assets/products/${escapeHtml(product.image)}"
      alt="${escapeHtml(product.name)} product photo"
      loading="${loading}"
      decoding="async"
    />
  `;

  const id = `p${product.id}-${size}`;
  const bag = bagPath(product.shape);
  const strap = strapPath(product.shape);
  const hardware = hardwareShape(product.shape);
  const pattern = patternMarkup(product.pattern, id, product.base, product.accent);
  const shadow = size === "thumb" ? 0.14 : 0.22;

  return `
    <svg viewBox="0 0 420 420" role="img" aria-label="${escapeHtml(product.name)} product image">
      <defs>
        <linearGradient id="${id}-bg" x1="0" x2="1" y1="0" y2="1">
          <stop offset="0" stop-color="#ffffff"/>
          <stop offset="1" stop-color="${escapeHtml(tint(product.accent, 0.74))}"/>
        </linearGradient>
        <linearGradient id="${id}-body" x1="0" x2="1" y1="0" y2="1">
          <stop offset="0" stop-color="${escapeHtml(tint(product.base, 0.2))}"/>
          <stop offset="0.55" stop-color="${escapeHtml(product.base)}"/>
          <stop offset="1" stop-color="${escapeHtml(shade(product.base, 0.22))}"/>
        </linearGradient>
        <filter id="${id}-shadow" x="-30%" y="-30%" width="160%" height="170%">
          <feDropShadow dx="0" dy="20" stdDeviation="18" flood-color="#171412" flood-opacity="${shadow}"/>
        </filter>
        ${pattern.defs}
      </defs>
      <rect width="420" height="420" fill="url(#${id}-bg)"/>
      <circle cx="${80 + product.id * 7 % 250}" cy="${66 + product.id * 17 % 220}" r="${46 + product.id % 5 * 9}" fill="${escapeHtml(product.accent)}" opacity="0.16"/>
      <circle cx="${330 - product.id * 3 % 160}" cy="${330 - product.id * 11 % 170}" r="${38 + product.id % 6 * 8}" fill="${escapeHtml(product.base)}" opacity="0.12"/>
      ${strap ? `<path d="${strap}" fill="none" stroke="${escapeHtml(shade(product.base, 0.34))}" stroke-width="20" stroke-linecap="round"/>` : ""}
      <path d="${bag}" fill="url(#${id}-body)" filter="url(#${id}-shadow)"/>
      <path d="${bag}" fill="url(#${id}-pattern)" opacity="${pattern.opacity}"/>
      <path d="${bag}" fill="none" stroke="${escapeHtml(tint(product.base, 0.42))}" stroke-width="5" opacity="0.62"/>
      ${hardware}
      <text x="210" y="382" text-anchor="middle" fill="#171412" font-size="17" font-weight="800">RuShop</text>
    </svg>
  `;
}

function bagPath(shape) {
  const paths = {
    tote: "M120 142 Q124 95 168 95 H252 Q296 95 300 142 L326 318 Q329 346 302 350 H118 Q91 346 94 318 Z",
    satchel: "M104 154 Q111 119 144 113 H276 Q309 119 316 154 L334 315 Q338 348 304 352 H116 Q82 348 86 315 Z",
    camera: "M98 165 Q98 136 127 136 H293 Q322 136 322 165 V308 Q322 337 293 337 H127 Q98 337 98 308 Z",
    clutch: "M82 180 Q82 154 108 154 H312 Q338 154 338 180 V294 Q338 320 312 320 H108 Q82 320 82 294 Z",
    bucket: "M126 126 H294 L320 328 Q323 353 298 354 H122 Q97 353 100 328 Z",
    backpack: "M116 128 Q125 93 210 93 Q295 93 304 128 L326 318 Q331 353 296 356 H124 Q89 353 94 318 Z",
    crescent: "M90 238 Q138 107 296 127 Q349 139 329 197 Q302 278 210 309 Q121 339 90 238 Z",
    mini: "M132 151 Q132 126 157 126 H263 Q288 126 288 151 V303 Q288 328 263 328 H157 Q132 328 132 303 Z",
    shopper: "M92 126 H328 L300 352 H120 Z",
    frame: "M102 166 Q102 132 136 132 H284 Q318 132 318 166 V310 Q318 344 284 344 H136 Q102 344 102 310 Z",
    hobo: "M88 220 Q95 112 202 111 Q326 111 334 220 Q339 327 272 346 H148 Q81 327 88 220 Z",
    saddle: "M94 196 Q111 128 210 128 Q309 128 326 196 L312 316 Q309 344 280 344 H140 Q111 344 108 316 Z",
    baguette: "M78 180 Q78 150 108 150 H312 Q342 150 342 180 V270 Q342 300 312 300 H108 Q78 300 78 270 Z",
    vanity: "M108 142 Q108 116 134 116 H286 Q312 116 312 142 V316 Q312 342 286 342 H134 Q108 342 108 316 Z",
    duffle: "M80 190 Q84 140 134 136 H286 Q336 140 340 190 L326 310 Q322 344 288 346 H132 Q98 344 94 310 Z",
    envelope: "M76 166 H344 V310 H76 Z",
    tophandle: "M98 158 Q103 126 135 120 H285 Q317 126 322 158 L334 315 Q337 346 306 350 H114 Q83 346 86 315 Z",
    sling: "M119 128 Q159 82 243 103 Q329 125 326 209 Q322 314 229 340 Q137 365 96 290 Q61 218 119 128 Z",
    box: "M112 132 H308 Q334 132 334 158 V312 Q334 338 308 338 H112 Q86 338 86 312 V158 Q86 132 112 132 Z",
    flap: "M96 158 Q96 126 128 126 H292 Q324 126 324 158 V318 Q324 350 292 350 H128 Q96 350 96 318 Z",
    doctor: "M86 186 Q94 124 156 116 H264 Q326 124 334 186 L326 320 Q323 350 292 352 H128 Q97 350 94 320 Z",
    belt: "M72 190 Q72 154 108 154 H312 Q348 154 348 190 V284 Q348 320 312 320 H108 Q72 320 72 284 Z",
    pouch: "M102 160 Q110 124 164 120 H256 Q310 124 318 160 L300 318 Q297 346 270 350 H150 Q123 346 120 318 Z",
    raffia: "M90 120 H330 L300 350 H120 Z"
  };
  return paths[shape] || paths.tote;
}

function strapPath(shape) {
  if (["clutch", "envelope", "box", "pouch"].includes(shape)) return "";
  if (["crossbody", "camera", "saddle", "sling", "belt"].includes(shape)) return "M72 310 C154 126 266 92 354 118";
  if (shape === "backpack") return "M112 300 C42 210 82 98 184 100 M308 300 C378 210 338 98 236 100";
  if (shape === "bucket") return "M132 136 C138 70 282 70 288 136";
  if (shape === "duffle") return "M145 144 C155 82 265 82 275 144";
  return "M148 146 C154 78 266 78 272 146";
}

function hardwareShape(shape) {
  const common = '<circle cx="210" cy="244" r="18" fill="#f2cc73" stroke="#6d4b1e" stroke-width="5"/>';
  const shapes = {
    clutch: '<path d="M94 182 L210 248 L326 182" fill="none" stroke="#f1cc77" stroke-width="8" opacity="0.9"/>',
    envelope: '<path d="M76 166 L210 258 L344 166" fill="none" stroke="#f1cc77" stroke-width="8"/><circle cx="210" cy="258" r="15" fill="#f1cc77"/>',
    baguette: '<rect x="170" y="170" width="80" height="22" rx="11" fill="#f1cc77"/>',
    backpack: '<rect x="178" y="162" width="64" height="22" rx="11" fill="#f1cc77"/><path d="M148 214 H272" stroke="#f1cc77" stroke-width="7"/>',
    raffia: '<path d="M122 162 H298 M113 222 H307 M106 284 H314" stroke="#161616" stroke-width="5" opacity="0.6"/>'
  };
  return shapes[shape] || common;
}

function patternMarkup(pattern, id, base, accent) {
  const safeBase = escapeHtml(base);
  const safeAccent = escapeHtml(accent);
  const defs = {
    stripe: `<pattern id="${id}-pattern" width="26" height="26" patternUnits="userSpaceOnUse" patternTransform="rotate(35)"><rect width="10" height="26" fill="${safeAccent}"/></pattern>`,
    window: `<pattern id="${id}-pattern" width="46" height="46" patternUnits="userSpaceOnUse"><rect x="5" y="5" width="32" height="32" fill="none" stroke="${safeAccent}" stroke-width="5"/></pattern>`,
    dot: `<pattern id="${id}-pattern" width="34" height="34" patternUnits="userSpaceOnUse"><circle cx="9" cy="9" r="5" fill="${safeAccent}"/><circle cx="26" cy="26" r="3" fill="#ffffff"/></pattern>`,
    fan: `<pattern id="${id}-pattern" width="54" height="54" patternUnits="userSpaceOnUse"><path d="M0 54 Q27 0 54 54" fill="none" stroke="${safeAccent}" stroke-width="5"/></pattern>`,
    wave: `<pattern id="${id}-pattern" width="62" height="24" patternUnits="userSpaceOnUse"><path d="M0 12 Q15 0 31 12 T62 12" fill="none" stroke="${safeAccent}" stroke-width="5"/></pattern>`,
    grid: `<pattern id="${id}-pattern" width="34" height="34" patternUnits="userSpaceOnUse"><path d="M34 0 H0 V34" fill="none" stroke="${safeAccent}" stroke-width="4"/></pattern>`,
    arc: `<pattern id="${id}-pattern" width="42" height="42" patternUnits="userSpaceOnUse"><path d="M4 36 Q21 4 38 36" fill="none" stroke="${safeAccent}" stroke-width="5"/></pattern>`,
    spot: `<pattern id="${id}-pattern" width="48" height="48" patternUnits="userSpaceOnUse"><circle cx="24" cy="24" r="15" fill="${safeAccent}" opacity="0.85"/></pattern>`,
    basket: `<pattern id="${id}-pattern" width="34" height="34" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><path d="M0 10 H34 M0 24 H34" stroke="${safeAccent}" stroke-width="5"/></pattern>`,
    gem: `<pattern id="${id}-pattern" width="58" height="58" patternUnits="userSpaceOnUse"><path d="M29 4 L54 29 L29 54 L4 29 Z" fill="none" stroke="${safeAccent}" stroke-width="5"/></pattern>`,
    petal: `<pattern id="${id}-pattern" width="62" height="62" patternUnits="userSpaceOnUse"><path d="M31 8 C52 20 52 42 31 54 C10 42 10 20 31 8Z" fill="${safeAccent}"/></pattern>`,
    stitch: `<pattern id="${id}-pattern" width="42" height="18" patternUnits="userSpaceOnUse"><path d="M4 9 H18 M26 9 H38" stroke="${safeAccent}" stroke-width="5" stroke-linecap="round"/></pattern>`,
    shine: `<pattern id="${id}-pattern" width="56" height="56" patternUnits="userSpaceOnUse"><path d="M8 48 L48 8" stroke="#ffffff" stroke-width="8" opacity="0.9"/></pattern>`,
    tile: `<pattern id="${id}-pattern" width="52" height="52" patternUnits="userSpaceOnUse"><path d="M0 0 H52 V52 H0Z M26 0 V52 M0 26 H52" fill="none" stroke="${safeAccent}" stroke-width="4"/></pattern>`,
    band: `<pattern id="${id}-pattern" width="70" height="70" patternUnits="userSpaceOnUse"><rect y="24" width="70" height="20" fill="${safeAccent}"/></pattern>`,
    chevron: `<pattern id="${id}-pattern" width="54" height="36" patternUnits="userSpaceOnUse"><path d="M0 4 L27 31 L54 4" fill="none" stroke="${safeAccent}" stroke-width="6"/></pattern>`,
    croc: `<pattern id="${id}-pattern" width="64" height="48" patternUnits="userSpaceOnUse"><rect x="6" y="6" width="26" height="15" rx="6" fill="none" stroke="${safeAccent}" stroke-width="4"/><rect x="34" y="25" width="24" height="15" rx="6" fill="none" stroke="${safeAccent}" stroke-width="4"/></pattern>`,
    diagonal: `<pattern id="${id}-pattern" width="36" height="36" patternUnits="userSpaceOnUse" patternTransform="rotate(-35)"><rect width="8" height="36" fill="${safeAccent}"/></pattern>`,
    marble: `<pattern id="${id}-pattern" width="80" height="80" patternUnits="userSpaceOnUse"><path d="M-10 58 C20 18 44 102 90 42" fill="none" stroke="${safeAccent}" stroke-width="8"/><path d="M-8 20 C28 56 44 -14 88 22" fill="none" stroke="#ffffff" stroke-width="5"/></pattern>`,
    panel: `<pattern id="${id}-pattern" width="84" height="84" patternUnits="userSpaceOnUse"><rect x="16" y="0" width="14" height="84" fill="${safeAccent}"/><rect x="54" y="0" width="8" height="84" fill="#ffffff"/></pattern>`,
    ribbon: `<pattern id="${id}-pattern" width="68" height="68" patternUnits="userSpaceOnUse"><path d="M8 34 C18 8 50 8 60 34 C50 60 18 60 8 34Z" fill="none" stroke="${safeAccent}" stroke-width="6"/></pattern>`,
    snow: `<pattern id="${id}-pattern" width="58" height="58" patternUnits="userSpaceOnUse"><path d="M29 8 V50 M8 29 H50 M14 14 L44 44 M44 14 L14 44" stroke="${safeAccent}" stroke-width="5" stroke-linecap="round"/></pattern>`,
    quilt: `<pattern id="${id}-pattern" width="42" height="42" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><path d="M0 0 H42 V42 H0Z" fill="none" stroke="${safeAccent}" stroke-width="4"/></pattern>`,
    line: `<pattern id="${id}-pattern" width="28" height="28" patternUnits="userSpaceOnUse"><path d="M14 0 V28" stroke="${safeAccent}" stroke-width="5"/></pattern>`,
    leaf: `<pattern id="${id}-pattern" width="60" height="60" patternUnits="userSpaceOnUse"><path d="M12 36 C18 12 42 12 48 36 C34 44 24 44 12 36Z" fill="${safeAccent}"/></pattern>`,
    orbit: `<pattern id="${id}-pattern" width="70" height="42" patternUnits="userSpaceOnUse"><ellipse cx="35" cy="21" rx="28" ry="12" fill="none" stroke="${safeAccent}" stroke-width="5"/></pattern>`,
    tech: `<pattern id="${id}-pattern" width="54" height="54" patternUnits="userSpaceOnUse"><path d="M8 8 H46 V46 H8Z M8 27 H46 M27 8 V46" fill="none" stroke="${safeAccent}" stroke-width="4"/></pattern>`,
    sun: `<pattern id="${id}-pattern" width="58" height="58" patternUnits="userSpaceOnUse"><circle cx="29" cy="29" r="10" fill="${safeAccent}"/><path d="M29 4 V16 M29 42 V54 M4 29 H16 M42 29 H54" stroke="${safeAccent}" stroke-width="5"/></pattern>`,
    weave: `<pattern id="${id}-pattern" width="34" height="34" patternUnits="userSpaceOnUse"><path d="M0 8 H34 M0 26 H34 M8 0 V34 M26 0 V34" stroke="${safeAccent}" stroke-width="5"/></pattern>`,
    pine: `<pattern id="${id}-pattern" width="60" height="60" patternUnits="userSpaceOnUse"><path d="M30 6 L50 50 H10Z M30 20 L44 50 H16Z" fill="${safeAccent}"/></pattern>`
  };

  return {
    defs: defs[pattern] || `<pattern id="${id}-pattern" width="40" height="40" patternUnits="userSpaceOnUse"><rect width="20" height="20" fill="${safeAccent}"/></pattern>`,
    opacity: ["shine", "marble"].includes(pattern) ? "0.34" : "0.28"
  };
}

function hexToRgb(hex) {
  const cleaned = hex.replace("#", "");
  return {
    r: parseInt(cleaned.slice(0, 2), 16),
    g: parseInt(cleaned.slice(2, 4), 16),
    b: parseInt(cleaned.slice(4, 6), 16)
  };
}

function rgbToHex({ r, g, b }) {
  return `#${[r, g, b].map((v) => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, "0")).join("")}`;
}

function tint(hex, amount) {
  const rgb = hexToRgb(hex);
  return rgbToHex({
    r: rgb.r + (255 - rgb.r) * amount,
    g: rgb.g + (255 - rgb.g) * amount,
    b: rgb.b + (255 - rgb.b) * amount
  });
}

function shade(hex, amount) {
  const rgb = hexToRgb(hex);
  return rgbToHex({
    r: rgb.r * (1 - amount),
    g: rgb.g * (1 - amount),
    b: rgb.b * (1 - amount)
  });
}

function getVisibleProducts() {
  const query = state.query.trim().toLowerCase();
  let visible = products.filter((product) => {
    const inCategory = state.category === "All" || product.category === state.category;
    const haystack = `${product.name} ${product.category} ${product.material} ${product.color}`.toLowerCase();
    return inCategory && (!query || haystack.includes(query));
  });

  if (state.sort === "price-low") visible = [...visible].sort((a, b) => a.price - b.price);
  if (state.sort === "price-high") visible = [...visible].sort((a, b) => b.price - a.price);
  if (state.sort === "name") visible = [...visible].sort((a, b) => a.name.localeCompare(b.name));

  return visible;
}

function renderProducts() {
  const visible = getVisibleProducts();
  grid.replaceChildren();

  visible.forEach((product) => {
    const node = template.content.firstElementChild.cloneNode(true);
    node.querySelector(".product-art").innerHTML = productArt(product);
    node.querySelector(".image-button").addEventListener("click", () => openQuick(product));
    node.querySelector(".image-button").setAttribute("aria-label", `Quick view ${product.name}`);
    node.querySelector(".product-category").textContent = product.category;
    node.querySelector("h3").textContent = product.name;
    node.querySelector(".product-meta").textContent = `${product.color} · ${product.material}`;
    node.querySelector(".product-price").textContent = money(product.price);
    node.querySelector(".add-button").addEventListener("click", () => addToCart(product));
    grid.append(node);
  });

  resultCount.textContent = `${visible.length} ${visible.length === 1 ? "product" : "products"}`;
  emptyState.hidden = visible.length > 0;
}

function addToCart(product) {
  const existing = state.cart.find((item) => item.id === product.id);
  if (existing) {
    existing.quantity += 1;
  } else {
    state.cart.push({ ...product, quantity: 1 });
  }
  renderCart();
}

function removeFromCart(productId) {
  state.cart = state.cart.filter((item) => item.id !== productId);
  renderCart();
}

function renderCart() {
  const count = state.cart.reduce((sum, item) => sum + item.quantity, 0);
  const total = state.cart.reduce((sum, item) => sum + item.quantity * item.price, 0);
  cartCount.textContent = count;
  cartTotal.textContent = money(total);
  checkoutButton.disabled = count === 0;

  if (state.cart.length === 0) {
    cartItems.innerHTML = '<p class="empty-state">Your cart is empty. Add a RuShop bag to begin.</p>';
    return;
  }

  cartItems.replaceChildren(
    ...state.cart.map((item) => {
      const line = document.createElement("div");
      line.className = "cart-line";
      line.innerHTML = `
        <div class="cart-thumb">${productArt(item, "thumb")}</div>
        <div>
          <h3>${escapeHtml(item.name)}</h3>
          <p>${escapeHtml(item.color)} · Qty ${item.quantity}</p>
          <p>${money(item.price * item.quantity)}</p>
        </div>
        <button class="remove-button" type="button">Remove</button>
      `;
      line.querySelector("button").addEventListener("click", () => removeFromCart(item.id));
      return line;
    })
  );
}

function openDrawer() {
  cartDrawer.classList.add("open");
  cartDrawer.setAttribute("aria-hidden", "false");
  closeCart.focus();
}

function closeDrawer() {
  cartDrawer.classList.remove("open");
  cartDrawer.setAttribute("aria-hidden", "true");
  openCart.focus();
}

function openQuick(product) {
  previousFocus = document.activeElement;
  activeQuickProduct = product;
  document.querySelector("#quickArt").innerHTML = productArt(product, "quick");
  document.querySelector("#quickCategory").textContent = product.category;
  document.querySelector("#quickName").textContent = product.name;
  document.querySelector("#quickDescription").textContent = product.description;
  document.querySelector("#quickMaterial").textContent = product.material;
  document.querySelector("#quickColor").textContent = product.color;
  document.querySelector("#quickCapacity").textContent = product.capacity;
  document.querySelector("#quickPrice").textContent = money(product.price);
  quickView.showModal();
  closeQuickView.focus();
}

function closeQuick() {
  quickView.close();
  if (previousFocus && typeof previousFocus.focus === "function") previousFocus.focus();
}

searchInput.addEventListener("input", (event) => {
  state.query = event.target.value;
  renderProducts();
});

sortSelect.addEventListener("change", (event) => {
  state.sort = event.target.value;
  renderProducts();
});

categoryButtons.forEach((button) => {
  button.addEventListener("click", () => {
    state.category = button.dataset.category;
    categoryButtons.forEach((item) => item.classList.toggle("active", item === button));
    renderProducts();
  });
});

openCart.addEventListener("click", openDrawer);
closeCart.addEventListener("click", closeDrawer);
cartDrawer.addEventListener("click", (event) => {
  if (event.target === cartDrawer) closeDrawer();
});

closeQuickView.addEventListener("click", closeQuick);
quickAdd.addEventListener("click", () => {
  if (activeQuickProduct) addToCart(activeQuickProduct);
  closeQuick();
});

document.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && cartDrawer.classList.contains("open")) {
    closeDrawer();
  }
});

renderProducts();
renderCart();
